// Filename - images.js

// Replace src value with ypur image url
const images = [
	{
		id: 1,
		src: "image1.jpg",
		alt: "Image 1",
	},
	{
		id: 2,
		src: "image2.jpg",
		alt: "Image 2 ",
	},
	{
		id: 3,
		src: "image3.jpg",
		alt: "Image 3",
	},
];
export default images;
