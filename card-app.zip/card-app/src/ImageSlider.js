import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./App.css";
import React, { useState } from "react";

const ImageSlider = ({ images }) => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [isLoggedIn, setLoggedIn] = useState(false);
    const [error, setError] = useState("");
    const handleLogin = () => {
        
       
        if (!email.trim()) {
            setError("*Please Enter your Email");
            return;
        }
        if (!password.trim()) {
            setError("*Please Enter your Password");
            return;
        }
        setLoggedIn(true);
    };
    const settings = {
        infinite: true,
        dots: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        lazyLoad: true,
        autoplay: true,
        autoplaySpeed: 2000,
    };
    return (

        <div className="page-container">
            <center>
              <div className="logo-container">
                <img src="infi.jpg" alt="Logo" className="logo" style={{ width: '50px', height: '50px', display: 'block', margin: 'auto' }} />
            </div>
            </center>
            <div className="login-container">
                <div className="login-form-container">
                    {!isLoggedIn ? (
                        
                            
                        <table>
                            <h1>WALLET_LOGIN</h1>
                            <tbody>
                                
                                <tr>
                                    <td>
                                        <label><b>EMAIL</b></label>
                                    </td>
                                    <td>
                                        <input
                                            type="email"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                        />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label><b>PASSWORD</b></label>
                                    </td>
                                    <td>
                                        <input
                                            type="password"
                                            value={password}
                                            onChange={(e) => setPassword(e.target.value)}
                                        />
                                    </td>
                                </tr>
                                <tr>
                                <td colSpan="2">
                                        <button type="button" onClick={handleLogin} className="login-button">
                                            Login
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        
                    ) : (
                        <p>Welcome, {email}!</p>
                    )}
                    {error && <p style={{ color: "red" }}>{error}</p>}
                </div>
            </div>
            <div className="image-slider-container">
                <div className="tag">
                    <h1> Wallet Image Gallery</h1>
                </div>
                <div className="imgslider">
                    <Slider {...settings}>
                        {images.map((item) => (
                            <div key={item.id}>
                                <img src={item.src} alt={item.alt} />
                            </div>
                        ))}
                    </Slider>
                </div>
            </div>
        </div>
    );
};

export default ImageSlider;
